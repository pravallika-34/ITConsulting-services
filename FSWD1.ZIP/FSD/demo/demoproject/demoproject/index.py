from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    return render(request,'home.html')

def AboutUs(request):
    return render(request,'AboutUs.html')

def Services(request):
    return render(request,'Services.html')

def ContactUs(request):
    return render(request,'ContactUs.html')

def Blogs(request):
    return render(request,'Blogs.html')

def Career(request):
    return render(request,'Career.html')
